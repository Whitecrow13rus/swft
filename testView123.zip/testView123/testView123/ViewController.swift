//
//  ViewController.swift
//  testView123
//
//  Created by Admin on 20.07.17.
//  Copyright © 2017 Admin. All rights reserved.
//

import UIKit




class ViewController: UIViewController {

    
    var operat: Dictionary<String,(Double,Double)->Double> = [
        "Plus" : ({$0+$1}),
        "Minus": ({$0-$1}),
        "Division": ({$0/$1}),
        "Multyply":({$0*$1})
    ]
    var operation : String?
    @IBAction func buttomPress(_ sender: UIButton) {
        operation = sender.currentTitle
        performSegue(withIdentifier: "segue", sender: self)
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let secondView = segue.destination as! SeconndViewController
        secondView.f = operat[operation!]
    }


}

