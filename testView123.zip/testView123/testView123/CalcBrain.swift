//
//  CalcBrain.swift
//  testView123
//
//  Created by Admin on 20.07.17.
//  Copyright © 2017 Admin. All rights reserved.
//

import Foundation


enum Operation {
    case bynaryOperation ((Double,Double)->Double)
}

var operat: Dictionary<String,Operation> = [
    "Plus" : Operation.bynaryOperation({$0+$1}),
    "Minus": Operation.bynaryOperation({$0-$1}),
    "Division": Operation.bynaryOperation({$0/$1}),
    "Multyply": Operation.bynaryOperation({$0*$1})
]
