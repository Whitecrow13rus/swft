//
//  SeconndViewController.swift
//  testView123
//
//  Created by Admin on 20.07.17.
//  Copyright © 2017 Admin. All rights reserved.
//

import UIKit

class SeconndViewController: UIViewController {

    @IBOutlet weak var label2: UILabel!
    @IBOutlet weak var TextFieldOper1: UITextField!
    @IBOutlet weak var TextFieldOper2: UITextField!
    
    var operand1 : Double? {
        get {
            return Double(TextFieldOper1.text!)
        }
    }
    var operand2 : Double? {
        get {
            return Double(TextFieldOper2.text!)
        }
    }
    
    var f : ((Double, Double) -> (Double))?
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func getResult(_ sender: UIButton) {
        if operand1 != nil && operand2 != nil {
            label2.text=String(f!(operand1!,operand2!))
        }else {
            label2.text = "Error Operand"
        }
        //label2.text = String(f!(Double(TextFieldOper1.text!)!,Double(TextFieldOper2.text!)!))
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
